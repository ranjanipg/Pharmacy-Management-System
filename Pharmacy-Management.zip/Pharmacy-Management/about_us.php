<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>About Us</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="shortcut icon" href="images/icon.svg" type="image/x-icon">
    <link rel="stylesheet" href="css/sidenav.css">
    <link rel="stylesheet" href="css/home.css">
    <script src="js/restrict.js"></script>
    <style>
      .team-member img {
          width: 100px; /* Set the width to 100px */
          height: 100px; /* Set the height to 100px */
          border-radius: 50%;
      }
    </style>
  </head>
  <body>
    <?php include "sections/sidenav.html"; ?>
    <div class="container-fluid">
      <div class="container">
        <!-- header section -->
        <?php
          require "php/header.php";
          createHeader('home', 'about us', 'Home');
        ?>
        <!-- header section end -->

        <h1>Welcome to Pharmacy Information System!</h1>
        <p>At Pharmacy Information System, we are dedicated to enhancing pharmacy operations and patient care with our innovative technology.</p>
        <h2>Our Mission</h2>
        <p>To provide pharmacies with easy-to-use, reliable tools that improve efficiency and ensure patient safety.</p>
        <h2>Our Vision</h2>
        <p>To create a world where every pharmacy provides better service and healthier communities.</p>
        <p>Under the guidance of Prof. Parthasarathy P V<br>
           Dept of CSE<br>
           AMC ENGINEERING COLLEGE<br>
           Bangalore<br>
           <P>Email: <a href="mailto:parthasarathy.venugopal@amceducation.in">parthasarathy.venugopal@amceducation.in</a></p>
        <div class="team-member">
           <img src="images/Partha_sir.jpg" alt="Prof. Parthasarathy P V">
        
           <h2>Meet Our Team</h2>
        </div>
        <div class="team">
            <div class="team-member">
                <img src="images/Nisarga.jpg" alt="Nisarga">
                <h4>Nisarga G</h4>
                <p>Phone: 9731942231</p>
                <p>Email: <a href="mailto:nisargaraju99@gmail.com">nisargaraju99@gmail.com</a></p>
            </div>
            <div class="team-member">
                <img src="images\Ranjani.jpg" alt="P G Ranjani">
                <h4>P G Ranjani</h4>
                <p>Phone: 6362852556</p>
                <p>Email: <a href="mailto:ranjanipg6@gmail.com">ranjanipg6@gmail.com</a></p>
            </div>
        </div>
        <hr style="border-top: 2px solid #ff5252;">
      </div>
    </div>
  </body>
</html>
